package eu.kanade.aniyomi.animeextension.ar.arabshentai

import eu.kanade.aniyomi.multisrc.videosource.VideoSource

class Arabshentai : VideoSource(
    "Arabshentai",
    "https://arabshentai.com",
    "ar"
)